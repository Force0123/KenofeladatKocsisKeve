﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfAppPenztargep.Models;

namespace WpfAppPenztargep
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            Penztargep geza = new Penztargep();
            geza.Rogzit(12430, 'k');
            geza.Rogzit(3425, 'b');
            geza.Rogzit(430, 'k');
            geza.Rogzit(45630, 'k');
            
            kiiro.Items.Add(geza.TetelekSzama());

            kiiro.Items.Add(geza.NapiKeszpenzesForgalom());

            File.WriteAllLines("forgalom.txt",geza.GetCSVLine());   
        }
    }
}