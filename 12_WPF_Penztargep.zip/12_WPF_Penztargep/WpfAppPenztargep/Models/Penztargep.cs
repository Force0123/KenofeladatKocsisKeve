﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppPenztargep.Models
{

    public class Penztargep
    {
        List<Tetel> tetelek;

        // TODO figyelni arra, hogy csak nap elején 1x lehessen rögzíteni!
        //int nyitoOsszeg;

        public int TetelekSzama()
        {
            return tetelek.Count();
        }
        public int NapiForgalom()
        {
            return tetelek.Sum(t => t.Osszeg);
        }
        public int NapiKeszpenzesForgalom()
        {
            return tetelek.Where(t=>t.FizetesiMod=='k').Sum(t => t.Osszeg);
        }
        public int NapiBankartyasForgalom()
        {
            return tetelek.Where(t=>t.FizetesiMod=='b').Sum(t => t.Osszeg);
        }


        public Penztargep()
        {
            tetelek = new List<Tetel>();
            //nyitoOsszeg = 0;
        }

        public void Rogzit(int osszeg, char fizmod)
        {
            Tetel ujtetel;
            ujtetel = new Tetel(osszeg, fizmod);
            tetelek.Add(ujtetel);

            //tetelek.Add(new Tetel(osszeg, fizmod));

        }

        public List<string> GetCSVLine()
        {
            // TODO Ezt azért át kell írni!
            return new List<string>();
        }
    }
}
