﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppPenztargep.Models
{
    public class Tetel
    {
        DateTime idopont;
        int osszeg;
        char fizetesiMod;  // 'k' - készpénz; 'b' - bankártya

        public Tetel(int osszeg, char fizetesiMod)
        {
            this.osszeg = osszeg;
            this.fizetesiMod = fizetesiMod;
            this.idopont = DateTime.Now;

        }

        public DateTime Idopont { get => idopont; }
        public int Osszeg { get => osszeg; }
        public char FizetesiMod { get => fizetesiMod; }
    }
}
