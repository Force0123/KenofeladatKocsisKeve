using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace KENO
{
    internal class NapiKeno
    {
        public int Ev { get; init; }
        public int Het { get; init; }
        public int Nap { get; init; }
        public string HuzasDatum { get; init; } = string.Empty;
        public List<int> HuzottSzamok { get; } = new();

     
        public NapiKeno(string line)
        {
          
            var normalized = Regex.Replace(line.Trim(), "[;,]+", " ");
            var tokens = Regex.Split(normalized, @"\s+").Where(t => !string.IsNullOrWhiteSpace(t)).ToList();

            int idx = 0;

            Ev = ParseIntToken(tokens, ref idx);
            Het = ParseIntToken(tokens, ref idx);
            Nap = ParseIntToken(tokens, ref idx);

       
            if (idx < tokens.Count && !int.TryParse(tokens[idx], out _))
            {
                HuzasDatum = tokens[idx++];
            }

       
            for (; idx < tokens.Count; idx++)
            {
                if (int.TryParse(tokens[idx], out int num))
                {
                    HuzottSzamok.Add(num);
                }
               
            }
        }

        private static int ParseIntToken(List<string> tokens, ref int index)
        {
            if (index >= tokens.Count) return 0;
            if (int.TryParse(tokens[index], out int value))
            {
                index++;
                return value;
            }

          
            while (index < tokens.Count && !int.TryParse(tokens[index], out value))
            {
                index++;
            }

            if (index < tokens.Count)
            {
                index++;
                return value;
            }

            return 0;
        }

   
        public int TalalatSzam(IEnumerable<int> tippek)
        {
            if (tippek == null) return 0;
            var tippSet = new HashSet<int>(tippek);
            return HuzottSzamok.Count(n => tippSet.Contains(n));
        }

     
        public bool Helyes
        {
            get
            {
                if (HuzottSzamok.Count != 20) return false;
                if (HuzottSzamok.Any(n => n < 1 || n > 80)) return false;
                return HuzottSzamok.Distinct().Count() == HuzottSzamok.Count;
            }
        }

        public override string ToString()
        {
            var numbers = HuzottSzamok.Count > 0 ? string.Join(", ", HuzottSzamok) : "(no numbers)";
            return $"{Ev} week {Het} day {Nap} date {HuzasDatum} -> {numbers}";
        }
    }
}