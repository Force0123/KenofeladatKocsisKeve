﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace KENO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1. feladat - NapiKeno betoltes");

            var path = args.Length > 0 ? args[0] : "huzasok.csv";
          

            var allLines = File.ReadAllLines(path);
            if (allLines.Length <= 1)
            {
              
                return;
            }

            
            var draws = new List<NapiKeno>();
            for (int i = 1; i < allLines.Length; i++)
            {
                var lineNo = i + 1; 
                var line = allLines[i];
                if (string.IsNullOrWhiteSpace(line)) continue;
                try
                {
                    var nk = new NapiKeno(line);
                    draws.Add(nk);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Skipping line {lineNo}: parse error ({ex.Message})");
                }
            }

          
            var valid = draws.Count(d => d.Helyes);
            Console.WriteLine($"Helyes huzasok : {valid}");
            Console.WriteLine($"Helytelen huzasok: {draws.Count - valid}");



            
           
           

            Console.WriteLine();
            Console.WriteLine("Add meg a tippeket szóközzel elválasztva:");
            Console.Write("Tips: ");
            var input = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(input)) return;

            var tippek = input.Split(new[] { ' ', ',', ';', '\t' }, StringSplitOptions.RemoveEmptyEntries)
                              .Select(s => { int.TryParse(s, out var v); return v; })
                              .Where(v => v > 0 && v <= 80)
                              .Distinct()
                              .ToList();
            var sample = draws.Last();
            var talalat = sample.TalalatSzam(tippek);
            Console.WriteLine($"megadtál {tippek.Count} külömböző valid tippeket. Találatok: {talalat}");

           
           
        }
    }
}
